# A Simpile C++ Program

A function definition has four elements :  **[[return type]]** | **[[function name]]**| **[[parameter list]]** | **[[function body]]**

```
	int main (){
	return 0;
	}
```

In this Example, main has an empty list of parameters. [[§6.2.5]] will discuss the other parameter type that we can define for main. The *main* function is required to have a return type of *int*. The *int* type is a **[[build in type]]**, which means that it is one of the types the language defines.

On most systems, the value returned from main is a *status indicator*. A return value 0 indicates success. A nonzero return has a meaning that is defined by the system.

## 1.1 Compiling and Executing Program 

Having wirtten the program, we need to compile it. Here we can use our powerful IDE : *Visual Studio 2022*

### Program Source File Name Convention 
Program files are normally referred to as a *source file*. On most systems, the name of a source file ends with a suffix, the most common include *.cc, .cxx, .cpp, .cp and .C*

Different Compiler : **[[MSVC]]**、**[[GCC]]**、**[[Clang]]**、etc

## 1.2 A First Look At Inpot/Output

C++ language does not define any statements to do input or output. It includes an extensive *standard library* that procides IO. Most of the examples  use the *iostream* library. Fundamental to the iosteam library are two types named istream and ostream, which represent input and output streams, respectively. 

The library defines 4 IO objects : *cin | cout | cerr | clog*

### Writting to a Stream
*Output Operator : <<* : takes two operands : left-must be an *ostream* object, the right-must be a value to print. The Operator writes the given value on the given *ostream*. The result of the output operator is its left-hand operand. 

*endl operator* : a special value called a manipulator. Writing endls has the effect of ending the current line and flushing the buffer associated with that device. Flushing the buffer ensures that all the output the program has generated so far is actually written to the output stream, tather than sitting in memory waiting to be written. 

### Reading from a Stream
*Input Operator* : takes an *istream* as its left-hand operator and an object as its right-hand operator. 

## 1.5 Introducing Classes

A primary focus of the design of C++ is to make it possible to define class types that behave as naturally as the built-in types.
To use a class, we need not care about how it is implemented. Instead, what we need to know is what operations objects of thay type can perform.

Every Class defines a type. The type name is the same as the name of the class.  The most important things is :
> The Class defines all the actions that can be performed by objects of this class. That is, the Sales_item class defines what happens when a Sales_item object is created and what happens when the assignment, addition, or the input and output operators are applied to Sales_items.

