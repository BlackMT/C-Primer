## 2.1 Primitive Built-in Types

C++ defines a set of primitive types that include the *arithmetic types* and a special type named *void*.  The *arithmetic types* are simple and normal, the *void* type has no associated values and can be used in only a few circumstances, most commonly as the return type for functions that do not return a value. 
>当函数不返回任何值时实用*void*类型作为返回类型

*Machine -Level Representation of the Built-in Types*
Most Computer deal with memory as chunks of bits of sizes that are powers of 2. 
>计算机以2的整数次幂个比特作为块来处理内存

*The smallest chunk of addressable memory is refferred to as a "byte". The basic unit of storage, usually a small number of bytes, is refferred to as a "word".*
>可寻址最小内存块称为“字节”，存储的基本单元成为“字”

*To give meaning to memory at a given address, we must know the type of the value stored there. The type determines how many bits are used and how to interpret those bits*

Floating-point types represent : *single-, double- and extended-precision* value. The *float* and *double* types typically yield about *7* and *16* significant digits, respectively.*（ [[计算机组成原理浮点型有效位]]）*

### Type Conversions
It is useful to understand what happens when we assign a value of one type to an object of another type.
>当赋值给无符号类型一个超出它表示范围的值时，结果是初始值对无符号整型表示数值总数取模后的余数。
>当赋值给带符号类型一个超出它表示范围的值时，结果是未定义的，此时程序有可能继续工作，有可能崩溃。
  因此，切勿混用带符号类型和无符号类型。

## 2.2 Variables

Each variables in C++ has a type. The type determines the size and layout of the variables's memory, the range of values that can be stored within that memory, and the set of operations that can be applied to the variable. 

### Initializers
Initialization and assignment are different operations in C++. 
*Initialization happens when a variable is given a value when it is created. Assignment obliterates an object's current value and replaces that value with a new one.*

>C++ 11: The generalized use of curly braces{ } for initialization was introduced as part of the new standard.
>Now when we used with variables of bulit-in type, this form of initialization has one important property : The complier will not let us list initialize variables of bulit-in type if the initializer might lead to the loss of information.
>
```
	long double ld = 3.1415926536;
	int a{ld}, b = {ld}; //error
	int a(ld), b = ld;  //ok
```

### Default Initialization
>C++11 recommend initializing every object of built-in type. It is not always necessary, but it is easier and safer to provide an initializer until you can be certain it is safe to omit the initializer.


### Diferent Between Variable Declarations and Definitions
 C++ supports what is commonly known as separate compilation. 
 To support separate compilation, C++ distinguishes between declarations and definitions. A declaration makes a name known to the program. A file that wants to use a name defined elsewhere includes a declaration for that name. A definition creates the associated entity.
```
extern int i; // declaration
int i ; // definition
extern int i = 0; // definition
```
*Variables must be defined exactly once but can be declared many times.*
The distinction between a declaration and a definition may seem obscure at this point but is actually important. To use a variable in more than one file requires declarations that are separate from the variable’s definition. To use the same variable in multiple files, we must define that variable in one—and only one—file. Other files that use that variable must declare—but not define—that variable.

## 2.3 Compound Types(复合类型)
*引用*
引用类似魂器，*对引用的所有操作都是在与其绑定的对象上进行的*，但引用本身不是对象，它只是一个已经存在对象的另一个名字罢了；
因此，引用在初始化时，和变量的初始化不同。程序把引用和它的初始值绑定在一起，而不是把初始值拷贝给引用，一旦初始化完成，引用和初始化绑定对象绑定在一起，无法重新绑定到另一个对象上，所以*引用必须初始化*。
而且，*引用必须绑定在一个对象上，不能绑定在常量或表达式运算的结果上。* 引用的类型和引用的对象类型必须一致；

引用的声明形如：*&*
```
	int ival = 10 ;
	int &pp = ival;
```

*指针*
指针和引用不同，指针更像是一个职业替身，它有独立人格；*指针本身就是一个对象，因此可以对指针赋值拷贝*，而且因为是职业替身，拿钱办事，所以*在其生命周期内，可以先后指向不同的对象*（给不同的老板当替身），此外，*指针也不需要在定义的时候初始化*（不上班怎么了？）**【但最好还是初始化】** 在类型上，指针和引用一致，都*必须保证其自身的类型和间接访问对象的类型一致。* 

指针的声明形如：*
```
	int ival = 10;
	int *p = &ival;
``` 
*指针存放的是内存地址*，当要访问指针内的对象时，要实用解引用符*，直接访问指针本身返回的是一个内存地址；
空指针（null pointer)，在C++ 11的标准下，咱直接就硬性规定了必须用这种方法：
```
	int *ival = nullptr;
```
>*这里建议，所有的指针必须初始化*

### 赋值和指针
要搞清楚一条赋值语句到底是改变了指针的值还是改变了指针所指的对象的值，方法是记住*赋值永远是改变等号左侧的对象*，并观察是否有 * 符号；
当对指针进行其他操作时，例如比较、判断时，比的是地址；

### Void指针
Void指针是一种特殊指针，它能做的事情不多，但它有一个特点，它没有具体的类型，所以比较万能；

### 指向指针的指针
一段代码就懂了，两层或者三层指针嵌套的例子如下：
```
int main() {

    // insert code here...

    int ival = 10;

    int *p = &ival;

    int **pval = &p;

    int ***ppval = &pval;
    

    std::cout << ival << std::endl;

    std::cout << p << std::endl;

    std::cout << pval << std::endl;

    std::cout << ppval << std::endl;
    

    std::cout << *p << std::endl;

    std::cout << *pval << std::endl;

    std::cout << *ppval << std::endl;
    

    std::cout << **pval << std::endl;

    std::cout << **ppval << std::endl;
    

    std::cout << ***ppval << std::endl;

    return 0;

}
//结果
**10**

**0x7ff7bfeff328**

**0x7ff7bfeff320**

**0x7ff7bfeff318**

**10**

**0x7ff7bfeff328**

**0x7ff7bfeff320**

**10**

**0x7ff7bfeff328**

**10**
```

### 指向指针的引用
引用本身不是变量，所以指针不能指向引用但是存在对指针的引用，形式还比较奇怪，形如：
```
	int ival = 10;
	int *p  = &ival ;
	int *&y = p;
```
这里如何判断y的类型到底是什么，方法是：*从右向左阅读y的定义，距离变量名最近的符号就是变量类型；* 
## 2.4 const限定符
